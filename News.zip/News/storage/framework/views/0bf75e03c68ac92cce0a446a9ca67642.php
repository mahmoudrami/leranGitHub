<?php $__env->startSection('title', 'Testimonial'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h3 mb-4 text-gray-800">Edit Testimonial</h1>
    <form action="<?php echo e(route('admin.Testimonial.update', @$item->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <?php echo $__env->make('admins.testimonials._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/admins/testimonials/edit.blade.php ENDPATH**/ ?>