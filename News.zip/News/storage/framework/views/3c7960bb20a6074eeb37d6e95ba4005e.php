<?php $__env->startSection('title', 'Post'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-flex justify-content-between mb-3">
        <h1 class="h3 mb-4 text-gray-800">All Posts</h1>
        <a href="<?php echo e(route('admin.Post.create')); ?>" class="btn btn-secondary mr-5 h-75 p-2">add new</a>
    </div>
    <table class="table table-hover table-striped">
        <tr class="table-dark">
            <th>#</th>
            <th>image</th>
            <th>title</th>
            <th>Actions</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><img src="<?php echo e($item->image_path); ?>" width="140px" alt=""></td>
                <td><?php echo e($item->title); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.Post.edit', $item->id)); ?>" class="btn  btn-primary"><i
                            class="fas fa-edit"></i></a>
                    <form action="<?php echo e(route('admin.Post.destroy', $item->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger" type="button" onclick="deleteItem(event)"><i
                                class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">no Data Found</td>
            </tr>
        <?php endif; ?>

    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/admins/posts/index.blade.php ENDPATH**/ ?>