<?php $__env->startSection('css'); ?>
    <style>
        #previwe {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
            padding: 5px;
            border: 1px #aaaaaa dashed;
            transition: all 0.3 ease
        }

        #previwe:hover {
            opacity: 0.8;
        }

        .pass-wrapper {
            position: relative;
        }

        .pass-wrapper i {
            position: absolute;
            right: 15px;
            top: 20px
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-section">
        <div class="container">
            <form action="<?php echo e(route('editProfile')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <?php if(session('msg')): ?>
                        <div class="alert alert-<?php echo e(session('type')); ?> ">
                            <?php echo e(session('msg')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="col-5 d-flex justify-content-center">
                        <div class="mb-3">
                            <label for="image" class="pt-5"><img src="<?php echo e($user->image_path); ?>" id="previwe"
                                    alt=""></label>
                            <input type="file" name="name" accept="image/png,jpg" id="image" placeholder="Name"
                                onchange="showImg(event)" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                style="display: none">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="mb-3">
                            <label>Name</label>
                            <input type="text" name="name" placeholder="Name"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" name="email" placeholder="Email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled
                                value="<?php echo e($user->email); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label>Old Password</label>
                            <div class="pass-wrapper">
                                <input type="password" name="old_password" id="old-password"
                                    class="form-control old-password">
                                <i class="fas fa-eye"></i>
                            </div>
                            <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label>New Password</label>
                            <input type="password" name="password" disabled class="form-control new">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label>Confirm Passwrod</label>
                            <input type="password" disabled name="password_confirmation" class="form-control new">
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn btn-sm btn-success"><i class="fas fa-save"></i> Update</button>
                    </div>


                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function showImg(e) {
            const [file] = e.target.files
            if (file) {
                previwe.src = URL.createObjectURL(file)
            }
        }

        $('#old-password').blur(function() {
            console.log(33);
            $.ajax({
                url: "<?php echo e(route('checkPassword')); ?>",
                method: 'POST',
                data: {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'password': $(this).val(),
                },
                success: function(res) {
                    if (res) {
                        $('.new').attr('disabled', false);
                        $('#old-password').addClass('is-valid');
                        $('#old-password').removeClass('is-invalid');
                    } else {
                        $('.new').attr('disabled', true);
                        $('#old-password').addClass('is-invalid');
                        $('#old-password').removeClass('is-valid');
                    }
                }
            });

        })
        document.querySelector('.pass-wrapper i').onclick = () => {
            if ($('#old-password').attr('type') == 'password') {
                $('#old-password').attr('type', 'text');
            } else {
                $('#old-password').attr('type', 'password');
            }
        }
        setTimeout(() => {
            $('.alert').fadeOut();
        }, 3000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/website/profile.blade.php ENDPATH**/ ?>