<?php $__env->startSection('content'); ?>
    <input type="hidden" value="<?php echo e(Auth::check() ? '1' : '0'); ?>" name="Auth" id="Auth">
    <div class="untree_co-section product-section before-footer-section">
        <div class="container">
            <div class="row">
                <!-- Start Column 1 -->
                <?php $__currentLoopData = @$products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4 col-lg-3 mb-5">
                        <a class="product-item" href="#" data-id="<?php echo e($product->id); ?>">
                            <img src="<?php echo e($product->image_path); ?>" class="img-fluid product-thumbnail">
                            <h3 class="product-title"><?php echo e($product->name); ?></h3>
                            <strong class="product-price">$<?php echo e($product->price); ?></strong>
                            <span class="icon-cross">
                                <img src="<?php echo e(asset('website/images/cross.svg')); ?>" class="img-fluid">
                            </span>
                        </a>
                    </div>
                    <!-- End Column 1 -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <script>
        let checkAuth = document.querySelector('#Auth').value;
        console.log(checkAuth === '0' ? 'true' : 'false');
        document.querySelectorAll('.product-item').forEach(el => {
            el.onclick = (e) => {
                e.preventDefault();
                if (checkAuth === '1') {
                    let id = el.getAttribute('data-id');
                    $.ajax({
                        url: "<?php echo e(route('addCart')); ?>/" + id,
                        method: "POST",
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(res) {
                            Swal.fire({
                                position: "center",
                                icon: "success",
                                title: "add product to cart",
                                showConfirmButton: false,
                                timer: 1500
                            });
                        }
                    });
                } else {
                    window.location.href = "<?php echo e(route('login')); ?>"
                }
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/website/shop.blade.php ENDPATH**/ ?>