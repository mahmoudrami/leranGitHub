<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-flex justify-content-between mb-3">
        <h1 class="h3 mb-4 text-gray-800">All Products</h1>
        <a href="<?php echo e(route('admin.Product.create')); ?>" class="btn btn-secondary mr-5 h-75 p-2">add new</a>
    </div>
    <table class="table table-hover table-striped">
        <tr class="table-dark">
            <th>#</th>
            <th>image</th>
            <th>name</th>
            <th>price</th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><img src="<?php echo e($item->image_path); ?>" width="140" alt=""></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.Product.edit', $item->id)); ?>" class="btn  btn-primary"><i
                            class="fas fa-edit"></i></a>
                    <form action="<?php echo e(route('admin.Product.destroy', $item->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">no Data Found</td>
            </tr>
        <?php endif; ?>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/admins/products/index.blade.php ENDPATH**/ ?>