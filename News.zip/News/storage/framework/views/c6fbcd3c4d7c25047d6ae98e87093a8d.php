<?php $__env->startSection('title', 'Member'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h3 mb-4 text-gray-800">Add New Member</h1>
    <form action="<?php echo e(route('admin.Member.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admins.members._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\News\resources\views/admins/members/create.blade.php ENDPATH**/ ?>